import React, { useState, useEffect, useRef } from 'react';
import { UserRole, CustomerProfile } from '../types';
import { ChefHat, User, Lock, Phone, ArrowRight, UtensilsCrossed, KeyRound, ChevronLeft, Send, MessageSquare, Loader2, HelpCircle, AlertTriangle, WifiOff } from 'lucide-react';
import { auth, RecaptchaVerifier, signInWithPhoneNumber, db, setDoc, doc } from '../services/firebase';

interface LoginProps {
  onLogin: (role: UserRole, profile?: CustomerProfile) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [isAdminMode, setIsAdminMode] = useState(false);
  
  // Customer Login State
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  
  // OTP State
  const [showOtp, setShowOtp] = useState(false);
  const [otp, setOtp] = useState('');
  const [timer, setTimer] = useState(30);
  const [isLoading, setIsLoading] = useState(false);
  const [confirmationResult, setConfirmationResult] = useState<any>(null);
  const [showHelp, setShowHelp] = useState(false);

  // Admin Login State
  const [adminPass, setAdminPass] = useState('');
  const [error, setError] = useState('');

  const recaptchaVerifierRef = useRef<any>(null);

  // Timer logic for OTP
  useEffect(() => {
    let interval: any;
    if (showOtp && timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [showOtp, timer]);

  // Initialize ReCaptcha on Mount
  useEffect(() => {
    const initRecaptcha = async () => {
      const container = document.getElementById('recaptcha-container');
      
      if (container && !isAdminMode) {
        try {
          // Clean up existing instance if any to prevent duplicates or stale instances
          if ((window as any).recaptchaVerifier) {
            try { (window as any).recaptchaVerifier.clear(); } catch(e) {}
            (window as any).recaptchaVerifier = null;
          }
          if (recaptchaVerifierRef.current) {
             try { recaptchaVerifierRef.current.clear(); } catch(e) {}
             recaptchaVerifierRef.current = null;
          }

          // Create new verifier
          const verifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
            'size': 'invisible',
            'callback': (response: any) => {
                // reCAPTCHA solved, allow signInWithPhoneNumber.
                console.log("Recaptcha resolved");
            },
            'expired-callback': () => {
                // Response expired. Ask user to solve reCAPTCHA again.
                setError("Security check expired. Please refresh the page.");
                if ((window as any).recaptchaVerifier) {
                   try { (window as any).recaptchaVerifier.clear(); } catch(e) {}
                   (window as any).recaptchaVerifier = null;
                }
            }
          });
          
          await verifier.render();
          recaptchaVerifierRef.current = verifier;
          (window as any).recaptchaVerifier = verifier;
          console.log("Recaptcha initialized successfully");
        } catch (error: any) {
          console.error("Recaptcha initialization failed:", error);
          if (error.code === 'auth/internal-error' || error.message?.includes('internal-error')) {
              setError("CRITICAL: Domain not authorized in Firebase Console. Please add this website URL to Authorized Domains in Firebase Authentication Settings.");
              setShowHelp(true);
          }
        }
      }
    };

    // Initialize with a small delay to ensure DOM is ready
    const timeoutId = setTimeout(initRecaptcha, 800);

    return () => {
      clearTimeout(timeoutId);
      if ((window as any).recaptchaVerifier) {
        try { (window as any).recaptchaVerifier.clear(); } catch(e) {}
        (window as any).recaptchaVerifier = null;
      }
    };
  }, [isAdminMode]);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setShowHelp(false);
    
    if (!name.trim()) {
       setError('Please enter your full name');
       return;
    }
    if (!mobile.trim() || mobile.trim().length < 10) {
       setError('Please enter a valid 10-digit mobile number');
       return;
    }

    setIsLoading(true);

    try {
      const phoneNumber = "+91" + mobile;
      
      // Check if verifier is ready
      let appVerifier = (window as any).recaptchaVerifier;
      if (!appVerifier) {
           setError("Security system not ready. Please refresh the page.");
           setIsLoading(false);
           return;
      }

      const result = await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
      
      setConfirmationResult(result);
      setShowOtp(true);
      setTimer(30);
      setOtp('');
    } catch (err: any) {
      console.error("Error sending OTP:", err);
      let msg = 'Failed to send OTP.';
      
      if (err.code === 'auth/invalid-phone-number') msg = 'Invalid phone number format.';
      else if (err.code === 'auth/quota-exceeded') msg = 'SMS quota exceeded for today.';
      else if (err.code === 'auth/user-disabled') msg = 'This user account is disabled.';
      else if (err.code === 'auth/operation-not-allowed') {
          msg = 'Phone Auth is disabled in Firebase Console.';
          setShowHelp(true);
      }
      else if (err.code === 'auth/internal-error') {
          msg = 'Domain Not Authorized in Firebase.';
          setShowHelp(true);
      } else if (err.message && err.message.includes('domain')) {
          msg = 'Domain not authorized.';
          setShowHelp(true);
      } else if (err.code === 'auth/network-request-failed') {
          msg = 'Network error. Check internet connection.';
      }
      
      setError(msg);
      
      // If critical error, clear recaptcha to force re-render on next attempt
      if (err.code === 'auth/internal-error') {
          if ((window as any).recaptchaVerifier) {
             try { (window as any).recaptchaVerifier.clear(); } catch(e){}
             (window as any).recaptchaVerifier = null;
          }
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp) {
        setError("Please enter the OTP.");
        return;
    }
    
    setIsLoading(true);
    try {
      if (confirmationResult) {
        const userCredential = await confirmationResult.confirm(otp);
        const user = userCredential.user;

        const timestamp = new Date().toISOString();
        
        // 1. Save to Firestore
        await setDoc(doc(db, "users", user.uid), {
          name: name,
          mobile: mobile,
          role: 'customer',
          lastLogin: timestamp
        }, { merge: true });

        onLogin(UserRole.CUSTOMER, { name, mobile });
      } else {
        setError("Session expired. Please request OTP again.");
      }
    } catch (err: any) {
      console.error("Verification failed:", err);
      if (err.code === 'auth/invalid-verification-code') {
          setError('Incorrect OTP. Please check and try again.');
      } else {
          setError('Verification failed. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendOtp = () => {
     handleSendOtp({ preventDefault: () => {} } as React.FormEvent);
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPass === 'lalita@0192') { 
      onLogin(UserRole.ADMIN);
    } else {
      setError('Invalid Admin Password');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-navy-900 p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-brand-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 -translate-x-1/2 -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-brand-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 translate-x-1/3 translate-y-1/3"></div>

      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md relative z-10 border-t-4 border-brand-500">
        {/* Invisible Recaptcha Container */}
        <div id="recaptcha-container" className="mb-2"></div>

        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative mb-3">
             <div className="w-16 h-16 bg-gradient-to-br from-brand-400 to-brand-600 rounded-2xl rotate-3 flex items-center justify-center shadow-lg">
                <UtensilsCrossed className="w-8 h-8 text-white -rotate-3" />
             </div>
             <div className="absolute -bottom-2 -right-2 bg-navy-900 rounded-full p-1.5 border-2 border-white">
                <ChefHat className="w-4 h-4 text-white" />
             </div>
          </div>
          <h1 className="text-3xl font-extrabold text-navy-900 tracking-tight">Naudiha<span className="text-brand-500">Express</span></h1>
          <p className="text-gray-400 text-xs font-semibold uppercase tracking-widest mt-1">Premium Food Delivery</p>
        </div>

        {!isAdminMode ? (
          <div className="animate-in fade-in slide-in-from-right-4 duration-300">
            {!showOtp ? (
                <form onSubmit={handleSendOtp} className="space-y-5">
                    <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Full Name</label>
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <User className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full pl-10 pr-4 py-3.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all font-medium text-navy-900 placeholder-gray-400"
                        placeholder="e.g. Rahul Kumar"
                        />
                    </div>
                    </div>

                    <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Mobile Number</label>
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Phone className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                        type="tel"
                        required
                        value={mobile}
                        onChange={(e) => setMobile(e.target.value)}
                        className="w-full pl-10 pr-4 py-3.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all font-medium text-navy-900 placeholder-gray-400"
                        placeholder="e.g. 9876543210"
                        minLength={10}
                        maxLength={10}
                        />
                    </div>
                    <p className="text-xs text-gray-400 mt-1 ml-1 flex items-center gap-1">
                        <MessageSquare className="w-3 h-3" /> We'll send a 6-digit verification code
                    </p>
                    </div>

                    {error && (
                        <div className="bg-red-50 text-red-500 text-xs p-3 rounded-lg border border-red-100 flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                            <span>{error}</span>
                        </div>
                    )}
                    
                    {showHelp && (
                        <div className="bg-blue-50 text-blue-800 text-xs p-3 rounded-lg border border-blue-100 space-y-2">
                             <p className="font-bold flex items-center gap-1"><HelpCircle className="w-3 h-3"/> Troubleshooting:</p>
                             <ul className="list-disc pl-4 space-y-1">
                                <li><strong>Check Domain:</strong> Add your app URL to "Authorized Domains" in Firebase Authentication settings.</li>
                                <li><strong>Phone Auth:</strong> Ensure Phone provider is enabled in Sign-in methods.</li>
                                <li>Refresh the page if the security check fails repeatedly.</li>
                             </ul>
                        </div>
                    )}

                    <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-brand-500 to-brand-600 hover:from-brand-600 hover:to-brand-700 text-white font-bold py-4 px-6 rounded-xl flex items-center justify-center gap-3 transition-all transform hover:scale-[1.02] shadow-xl shadow-brand-500/20 disabled:opacity-70 disabled:cursor-not-allowed"
                    >
                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><span>Get OTP</span><Send className="w-4 h-4" /></>}
                    </button>
                    
                    <div className="relative flex py-4 items-center">
                        <div className="flex-grow border-t border-gray-200"></div>
                        <span className="flex-shrink-0 mx-4 text-gray-300 text-xs font-medium uppercase tracking-wider">Staff Access</span>
                        <div className="flex-grow border-t border-gray-200"></div>
                    </div>

                    <button
                    type="button"
                    onClick={() => { setIsAdminMode(true); setError(''); }}
                    className="w-full bg-white hover:bg-gray-50 text-navy-600 font-semibold py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-colors border border-gray-200 hover:border-gray-300"
                    >
                    <Lock className="w-4 h-4" />
                    <span>Admin Login</span>
                    </button>
                </form>
            ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-6 animate-in slide-in-from-right-8 duration-300">
                     <div className="text-center">
                        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <KeyRound className="w-6 h-6 text-green-600" />
                        </div>
                        <h3 className="text-lg font-bold text-navy-900">Enter Verification Code</h3>
                        <p className="text-sm text-gray-500">Sent to +91 {mobile}</p>
                     </div>

                     <div>
                        <input
                            type="text"
                            required
                            value={otp}
                            onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                            className="w-full text-center text-3xl tracking-[0.5em] font-bold py-4 rounded-xl border-2 border-brand-100 focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10 outline-none transition-all text-navy-900"
                            placeholder="••••••"
                            maxLength={6}
                            autoFocus
                        />
                     </div>

                     {error && <div className="bg-red-50 text-red-500 text-xs p-3 rounded-lg border border-red-100 text-center">{error}</div>}

                     <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full bg-gradient-to-r from-brand-500 to-brand-600 hover:from-brand-600 hover:to-brand-700 text-white font-bold py-4 px-6 rounded-xl flex items-center justify-center gap-2 transition-all shadow-xl shadow-brand-500/20 disabled:opacity-70 disabled:cursor-not-allowed"
                     >
                        {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><span>Verify & Login</span><ArrowRight className="w-5 h-5" /></>}
                     </button>

                     <div className="flex justify-between items-center text-sm">
                        <button
                            type="button"
                            onClick={() => { setShowOtp(false); setOtp(''); setError(''); setConfirmationResult(null); }}
                            className="flex items-center gap-1 text-gray-500 hover:text-navy-900 transition-colors"
                        >
                            <ChevronLeft className="w-4 h-4" /> Edit Number
                        </button>
                        
                        <button
                            type="button"
                            onClick={handleResendOtp}
                            disabled={timer > 0 || isLoading}
                            className={`font-medium transition-colors ${timer > 0 ? 'text-gray-300 cursor-not-allowed' : 'text-brand-600 hover:text-brand-700'}`}
                        >
                            {timer > 0 ? `Resend in ${timer}s` : 'Resend OTP'}
                        </button>
                     </div>
                </form>
            )}
          </div>
        ) : (
          <form onSubmit={handleAdminLogin} className="space-y-5 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="bg-navy-50 p-4 rounded-xl border border-navy-100 flex items-center gap-3">
                <div className="p-2 bg-navy-100 rounded-lg">
                    <Lock className="w-5 h-5 text-navy-600" />
                </div>
                <div>
                    <h3 className="text-sm font-bold text-navy-900">Secure Admin Portal</h3>
                    <p className="text-xs text-navy-500">Please authenticate to continue</p>
                </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
              <input
                type="password"
                value={adminPass}
                onChange={(e) => {
                  setAdminPass(e.target.value);
                  setError('');
                }}
                className="w-full px-4 py-3.5 rounded-xl border border-gray-300 focus:ring-2 focus:ring-navy-900 focus:border-navy-900 outline-none transition-all"
                placeholder="Enter admin password..."
              />
              {error && <p className="text-red-500 text-xs mt-2 ml-1">{error}</p>}
            </div>
            
            <button
              type="submit"
              className="w-full bg-navy-900 hover:bg-navy-800 text-white font-bold py-4 px-6 rounded-xl transition-colors shadow-lg flex justify-center items-center gap-2"
            >
              Access Dashboard
            </button>
            
            <button
              type="button"
              onClick={() => {
                setIsAdminMode(false);
                setError('');
                setAdminPass('');
              }}
              className="w-full text-gray-500 text-sm py-2 hover:text-navy-900 font-medium transition-colors"
            >
              ← Back to Customer Login
            </button>
          </form>
        )}
      </div>
      
      <div className="absolute bottom-4 text-navy-200/40 text-xs text-center">
        © 2024 Naudiha Food Express. All rights reserved.
      </div>
    </div>
  );
};