import React, { useState, useEffect } from 'react';
import { FoodItem, CartItem, DeliveryDetails, CustomerProfile, FoodCategory, Order, OrderStatus } from '../types';
import { ShoppingBag, Menu, X, Plus, Minus, Check, Sparkles, User, FileText, Info, LogOut, Clock, MapPin, Bike, UtensilsCrossed, ChevronRight, Receipt, Code } from 'lucide-react';
import { getFoodDescription } from '../services/geminiService';
import { db, collection, addDoc, onSnapshot, query, where, auth, signOut } from '../services/firebase';

// Specific Menu Data with Fixed Images
const MENU_ITEMS: FoodItem[] = [
  // Nasta (New Section)
  { id: '21', name: 'Chola Bhatura (2 pcs)', description: 'Fluffy fried bread with spicy chickpea curry.', price: 45, category: 'Nasta', image: 'https://i.imgur.com/ZArZ4BA.jpeg' },
  { id: '22', name: 'Kachori (5 pcs)', description: 'Crispy deep-fried pastry filled with spiced filling.', price: 55, category: 'Nasta', image: 'https://i.imgur.com/EFpZNdZ.png' },

  // Chinese
  { id: '1', name: 'Chowmin', description: 'Stir-fried noodles with fresh vegetables.', price: 60, category: 'Chinese', image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=800&q=80' },
  { id: '2', name: 'Chicken Chili with Chowmin', description: 'Spicy chicken chili combo with noodles.', price: 125, category: 'Chinese', image: 'https://i.imgur.com/n0Prvua.jpeg', isSpicy: true },
  { id: '3', name: 'Only Chicken Chili', description: 'Succulent chicken pieces in spicy sauce.', price: 110, category: 'Chinese', image: 'https://i.imgur.com/PjCkgIo.jpeg', isSpicy: true },
  { id: '4', name: 'Paneer Chili with Chowmin', description: 'Cottage cheese chili combo with noodles.', price: 125, category: 'Chinese', image: 'https://i.imgur.com/Ya5QcpM.jpeg', isSpicy: true },
  { id: '5', name: 'Only Paneer Chili', description: 'Spicy paneer cubes tossed in chili sauce.', price: 110, category: 'Chinese', image: 'https://i.imgur.com/oS9dWm3.jpeg', isSpicy: true },
  { id: '6', name: 'Manchurian with Chowmin', description: 'Veg manchurian balls with noodles.', price: 115, category: 'Chinese', image: 'https://i.imgur.com/56Zf648.png' },
  { id: '7', name: 'Only Manchurian', description: 'Delicious vegetable manchurian balls in gravy.', price: 95, category: 'Chinese', image: 'https://i.imgur.com/GtawX5V.jpeg' },
  { id: '8', name: 'Egg Chowmin (Full Plate)', description: 'Noodles tossed with scrambled eggs.', price: 75, category: 'Chinese', image: 'https://i.imgur.com/1Wn6DKn.jpeg' },
  { id: '12', name: 'Momos (12 pcs)', description: 'Steamed dumplings with savory filling.', price: 65, category: 'Chinese', image: 'https://i.imgur.com/Ioy4oD4.jpeg' },
  { id: '19', name: 'Chicken Lollipop (2 pcs)', description: 'Spicy and crispy chicken appetizers.', price: 105, category: 'Chinese', image: 'https://i.imgur.com/6y2EmGg.jpeg', isSpicy: true },
  { id: '20', name: 'Chicken Wings (8 pcs)', description: 'Juicy and flavorful chicken wings.', price: 110, category: 'Chinese', image: 'https://i.imgur.com/Vorb37i.jpeg', isSpicy: true },

  // Snacks
  { id: '9', name: 'Egg Roll', description: 'Flaky paratha roll stuffed with eggs.', price: 65, category: 'Snacks', image: 'https://i.imgur.com/DfiuUJS.png' },
  { id: '10', name: 'Burger', description: 'Classic veggie burger with cheese.', price: 65, category: 'Snacks', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80' },
  { id: '13', name: 'Samosa (Min 5 pcs)', description: 'Crispy pastry with spicy potato filling.', price: 50, category: 'Snacks', image: 'https://i.imgur.com/EVZJP0L.png' },
  { id: '14', name: 'Samosa Chat (Full Plate)', description: 'Crushed samosas topped with chutney and yogurt.', price: 50, category: 'Snacks', image: 'https://i.imgur.com/LXZuRQt.png' },

  // Main Course
  { id: '15', name: 'Biryani (Full Plate)', description: 'Aromatic rice dish with spices.', price: 149, category: 'Main Course', image: 'https://i.imgur.com/QRmGg2b.jpeg' },

  // Pizza
  { id: '30', name: 'Plain Cheese Pizza', description: 'Classic pizza topped with generous amounts of mozzarella cheese.', price: 179, category: 'Pizza', image: 'https://i.imgur.com/6fQH6WG.jpeg' },
  { id: '31', name: 'Corn Cheese Pizza', description: 'Sweet corn kernels paired with melting cheese on a crispy crust.', price: 199, category: 'Pizza', image: 'https://i.imgur.com/zqa2rbs.jpeg' },
  { id: '32', name: 'Onion Cheese Pizza', description: 'Crunchy onions and cheese make this a savory delight.', price: 195, category: 'Pizza', image: 'https://i.imgur.com/qTb05N7.jpeg' },
  { id: '33', name: 'Capsicum Cheese Pizza', description: 'Fresh capsicum slices and cheese for a zesty flavor.', price: 195, category: 'Pizza', image: 'https://i.imgur.com/BJ2jnxX.jpeg' },
  { id: '34', name: 'Mushroom Cheese Pizza', description: 'Earthy mushrooms and cheese on a perfectly baked base.', price: 199, category: 'Pizza', image: 'https://i.imgur.com/MeD9vhA.jpeg' },
  { id: '35', name: 'Paneer & Cheese Pizza', description: 'Soft paneer cubes and cheese, a favorite for vegetarians.', price: 199, category: 'Pizza', image: 'https://i.imgur.com/OpybIvU.jpeg' },
  { id: '36', name: 'Paneer & Veg Pizza', description: 'Loaded with paneer and mixed vegetables for a wholesome meal.', price: 209, category: 'Pizza', image: 'https://i.imgur.com/c70hIhD.jpeg' },

  // Dessert
  { id: '16', name: 'Pastry', description: 'Sweet and creamy pastry slice.', price: 45, category: 'Dessert', image: 'https://i.imgur.com/zggdiLg.jpeg' },
  { id: '17', name: 'Cup Cake', description: 'Soft and fluffy cupcake.', price: 55, category: 'Dessert', image: 'https://i.imgur.com/enT9WWo.jpeg' },
  { id: '18', name: 'Cake (1 Pound)', description: 'Celebration cake, design per request.', price: 310, category: 'Dessert', image: 'https://i.imgur.com/iaGLl9V.jpeg' },
];

const CATEGORIES: FoodCategory[] = ['Nasta', 'Chinese', 'Snacks', 'Main Course', 'Pizza', 'Dessert'];

interface DeliveryOption {
  range: string;
  price: number;
  label: string;
}

const DELIVERY_OPTIONS: DeliveryOption[] = [
  { range: '0-2km', price: 10, label: 'Nearby (0-2 km)' },
  { range: '2-5km', price: 20, label: 'Local (2-5 km)' },
  { range: '5-15km', price: 45, label: 'Distance (5-15 km)' },
];

interface CustomerPanelProps {
  user: CustomerProfile;
  onLogout: () => void;
}

export const CustomerPanel: React.FC<CustomerPanelProps> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'menu' | 'orders' | 'about'>('menu');
  const [activeCategory, setActiveCategory] = useState<FoodCategory>('Nasta');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [myOrders, setMyOrders] = useState<Order[]>([]);
  
  // Checkout State
  const [address, setAddress] = useState('');
  const [selectedDelivery, setSelectedDelivery] = useState<DeliveryOption>(DELIVERY_OPTIONS[0]);

  // AI
  const [aiDescriptions, setAiDescriptions] = useState<Record<string, string>>({});
  const [loadingAi, setLoadingAi] = useState<string | null>(null);

  // Feedback
  const [toast, setToast] = useState<string | null>(null);

  // Listen to My Orders
  useEffect(() => {
    if (user.mobile) {
      // FIX: Query without orderBy to avoid index error
      const q = query(
        collection(db, 'orders'),
        where('customerId', '==', user.mobile)
      );
      
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const ordersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
        // Sort client-side
        ordersData.sort((a, b) => b.timestamp - a.timestamp);
        setMyOrders(ordersData);
      });
      return () => unsubscribe();
    }
  }, [user.mobile]);

  const handleLogout = async () => {
    try {
        await signOut(auth);
        onLogout();
    } catch(e) {
        console.error("Logout failed", e);
    }
  };

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const addToCart = (item: FoodItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    showToast(`Added ${item.name} to cart`);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(i => i.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.id === id) {
        return { ...i, quantity: Math.max(1, i.quantity + delta) };
      }
      return i;
    }));
  };

  const cartSubtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const cartTotalCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const fetchAiDescription = async (id: string, name: string) => {
    if (aiDescriptions[id]) return; 
    setLoadingAi(id);
    const desc = await getFoodDescription(name);
    setAiDescriptions(prev => ({ ...prev, [id]: desc }));
    setLoadingAi(null);
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    const totalAmount = cartSubtotal + selectedDelivery.price;

    try {
      const orderData: Omit<Order, 'id'> = {
        customerId: user.mobile,
        items: cart,
        subtotal: cartSubtotal,
        deliveryCharge: selectedDelivery.price,
        totalAmount: totalAmount,
        deliveryDetails: {
          fullName: user.name,
          phone: user.mobile,
          address: address,
          distanceRange: selectedDelivery.range
        },
        status: OrderStatus.PENDING,
        timestamp: Date.now()
      };

      await addDoc(collection(db, 'orders'), orderData);
      
      setCart([]);
      setIsCheckoutOpen(false);
      setIsCartOpen(false);
      setAddress('');
      setSelectedDelivery(DELIVERY_OPTIONS[0]);
      showToast('Order placed successfully!');
      setActiveTab('orders'); // Switch to order view
    } catch (error) {
      console.error("Error placing order: ", error);
      alert("Failed to place order. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      {/* Sidebar */}
      <div className={`fixed inset-0 z-50 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out`}>
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsSidebarOpen(false)}></div>
        <div className="relative w-72 bg-navy-900 h-full shadow-2xl flex flex-col text-white">
          <div className="p-8 border-b border-navy-800 bg-navy-950">
            <div className="flex items-center gap-3 mb-2">
                 <div className="bg-brand-500 p-2 rounded-lg">
                    <UtensilsCrossed className="w-5 h-5 text-white" />
                 </div>
                <h2 className="text-xl font-bold tracking-tight">Naudiha<span className="text-brand-500">Express</span></h2>
            </div>
            <p className="text-navy-300 text-xs">Premium Food Delivery</p>
          </div>
          <nav className="flex-1 p-4 space-y-2">
            <button onClick={() => { setActiveTab('menu'); setIsSidebarOpen(false); }} className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${activeTab === 'menu' ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/20' : 'hover:bg-navy-800 text-gray-300'}`}>
              <ShoppingBag className="w-5 h-5" /> <span className="font-medium">Browse Menu</span>
            </button>
            <button onClick={() => { setActiveTab('orders'); setIsSidebarOpen(false); }} className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${activeTab === 'orders' ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/20' : 'hover:bg-navy-800 text-gray-300'}`}>
              <Receipt className="w-5 h-5" /> <span className="font-medium">Order History</span>
            </button>
            <button onClick={() => { setActiveTab('about'); setIsSidebarOpen(false); }} className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${activeTab === 'about' ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/20' : 'hover:bg-navy-800 text-gray-300'}`}>
              <Info className="w-5 h-5" /> <span className="font-medium">About Us</span>
            </button>
          </nav>
          <div className="p-4 border-t border-navy-800 bg-navy-950">
             <div className="flex items-center gap-3 mb-4 px-2">
                <div className="w-8 h-8 rounded-full bg-navy-800 flex items-center justify-center text-xs font-bold text-brand-500">
                    {user.name.charAt(0)}
                </div>
                <div>
                    <p className="text-sm font-medium text-white">{user.name}</p>
                    <p className="text-xs text-gray-500">{user.mobile}</p>
                </div>
             </div>
            <button onClick={handleLogout} className="w-full flex items-center gap-3 p-3 rounded-lg text-red-400 hover:bg-navy-800 transition-colors border border-navy-800 hover:border-red-900/50">
              <LogOut className="w-5 h-5" /> <span className="font-medium">Sign Out</span>
            </button>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 bg-white shadow-sm z-30 px-4 py-3 flex justify-between items-center border-b border-gray-100">
        <div className="flex items-center gap-3">
           <button onClick={() => setIsSidebarOpen(true)} className="p-2 text-navy-900 hover:bg-gray-100 rounded-lg transition-colors">
             <Menu className="w-6 h-6" />
           </button>
           <h1 className="text-lg font-bold text-navy-900 hidden sm:block">Naudiha<span className="text-brand-500">Express</span></h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex flex-col items-end mr-2">
            <span className="text-sm font-bold text-navy-900">{user.name}</span>
            <span className="text-[10px] text-gray-500 font-mono tracking-wider">ID: {user.mobile}</span>
          </div>
          <button 
            onClick={() => setIsCartOpen(true)}
            className="relative p-2.5 bg-gray-50 hover:bg-brand-50 text-navy-900 hover:text-brand-600 rounded-xl transition-all group"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartTotalCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-brand-500 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white group-hover:scale-110 transition-transform">
                {cartTotalCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 max-w-5xl">
        {activeTab === 'menu' && (
          <>
            {/* Category Filter */}
            <div className="flex overflow-x-auto no-scrollbar gap-3 mb-8 pb-2">
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`whitespace-nowrap px-5 py-2.5 rounded-xl font-medium transition-all text-sm ${
                    activeCategory === cat 
                      ? 'bg-navy-900 text-white shadow-lg shadow-navy-900/20 scale-105' 
                      : 'bg-white text-gray-600 border border-gray-200 hover:border-brand-300 hover:text-brand-600'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Menu Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {MENU_ITEMS.filter(item => item.category === activeCategory).map(item => (
                <div key={item.id} className="bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-xl transition-all border border-gray-100 group">
                  <div className="relative h-72 overflow-hidden">
                    <img 
                      src={item.image} 
                      alt={item.name} 
                      className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    {item.isSpicy && (
                      <span className="absolute top-3 right-3 bg-red-500 text-white text-[10px] uppercase tracking-wider px-2 py-1 rounded-md font-bold shadow-sm flex items-center gap-1">
                         Hot
                      </span>
                    )}
                  </div>
                  <div className="p-5">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-bold text-lg text-navy-900 leading-tight pr-2">{item.name}</h3>
                      <span className="font-bold text-brand-600 text-lg bg-brand-50 px-2 py-1 rounded-lg">₹{item.price}</span>
                    </div>
                    
                    <div className="mb-4 min-h-[60px]">
                      <p className="text-gray-500 text-sm line-clamp-2 leading-relaxed">
                         {aiDescriptions[item.id] || item.description}
                      </p>
                      {!aiDescriptions[item.id] && (
                        <button 
                          onClick={() => fetchAiDescription(item.id, item.name)}
                          className="mt-2 text-xs text-brand-500 font-semibold flex items-center gap-1.5 hover:text-brand-600 transition-colors py-1 px-2 rounded-md hover:bg-brand-50 w-fit -ml-2"
                          disabled={loadingAi === item.id}
                        >
                          <Sparkles className="w-3 h-3" />
                          {loadingAi === item.id ? "Thinking..." : "AI Describe"}
                        </button>
                      )}
                    </div>

                    <button
                      onClick={() => addToCart(item)}
                      className="w-full bg-navy-900 hover:bg-navy-800 text-white py-3 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 active:scale-[0.98] shadow-lg shadow-navy-900/10"
                    >
                      <Plus className="w-4 h-4" /> Add to Cart
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {activeTab === 'orders' && (
          <div className="max-w-2xl mx-auto space-y-6">
            <h2 className="text-2xl font-bold text-navy-900 mb-2 flex items-center gap-3">
                <Receipt className="w-6 h-6 text-brand-500" /> Order History
            </h2>
            {myOrders.length === 0 ? (
                <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-gray-200">
                    <div className="bg-gray-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Clock className="w-8 h-8 text-gray-300" />
                    </div>
                    <p className="text-gray-500 font-medium">No orders placed yet.</p>
                    <button onClick={() => setActiveTab('menu')} className="mt-4 text-brand-600 font-semibold text-sm hover:underline">Start Ordering</button>
                </div>
            ) : (
                myOrders.map(order => (
                <div key={order.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
                    <div className="p-4 border-b border-gray-50 bg-gray-50/50 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                            <div className="bg-white p-2 rounded-lg border border-gray-200">
                                <UtensilsCrossed className="w-5 h-5 text-navy-900" />
                            </div>
                            <div>
                                <p className="text-xs font-mono text-gray-400">ORDER #{order.id.slice(0, 8).toUpperCase()}</p>
                                <p className="text-xs text-gray-500 font-medium">{new Date(order.timestamp).toLocaleString()}</p>
                            </div>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold border ${
                            order.status === 'Delivered' ? 'bg-green-100 text-green-700 border-green-200' : 
                            order.status === 'Cancelled' ? 'bg-red-100 text-red-700 border-red-200' :
                            'bg-brand-50 text-brand-700 border-brand-100'
                        }`}>
                            {order.status}
                        </span>
                    </div>
                    
                    <div className="p-4">
                        <div className="space-y-2 mb-4">
                            {order.items.map((item, idx) => (
                                <div key={idx} className="flex justify-between text-sm items-center">
                                    <div className="flex items-center gap-2">
                                        <span className="text-xs font-bold bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{item.quantity}x</span>
                                        <span className="text-gray-700 font-medium">{item.name}</span>
                                    </div>
                                    <span className="text-gray-900">₹{item.price * item.quantity}</span>
                                </div>
                            ))}
                        </div>
                        
                        <div className="border-t border-dashed border-gray-200 pt-3 space-y-1">
                            <div className="flex justify-between text-xs text-gray-500">
                                <span>Item Total</span>
                                <span>₹{order.subtotal || order.totalAmount}</span>
                            </div>
                            {order.deliveryCharge !== undefined && (
                                <div className="flex justify-between text-xs text-gray-500">
                                    <span>Delivery Charge ({order.deliveryDetails.distanceRange})</span>
                                    <span>₹{order.deliveryCharge}</span>
                                </div>
                            )}
                            <div className="flex justify-between items-center pt-2 mt-2 border-t border-gray-100">
                                <span className="font-bold text-navy-900">Total Amount</span>
                                <span className="font-bold text-lg text-brand-600">₹{order.totalAmount}</span>
                            </div>
                        </div>

                        {order.status === OrderStatus.PENDING && (
                             <div className="mt-4 bg-yellow-50 text-yellow-800 text-xs p-3 rounded-lg flex gap-2 items-start">
                                <Clock className="w-4 h-4 shrink-0 mt-0.5" />
                                <p>Waiting for restaurant confirmation. Your food will be prepared shortly.</p>
                             </div>
                        )}
                    </div>
                </div>
                ))
            )}
          </div>
        )}

        {activeTab === 'about' && (
            <div className="bg-white rounded-2xl shadow-sm p-8 text-center max-w-2xl mx-auto border border-gray-100 relative overflow-hidden">
                <div className="bg-brand-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 relative z-10">
                    <UtensilsCrossed className="w-10 h-10 text-brand-600" />
                </div>
                <h2 className="text-3xl font-bold text-navy-900 mb-2 relative z-10">Naudiha<span className="text-brand-500">Express</span></h2>
                <div className="h-1 w-16 bg-brand-200 mx-auto rounded-full mb-6 relative z-10"></div>
                
                <div className="space-y-4 text-gray-600 mb-8 leading-relaxed relative z-10">
                    <p>
                        Naudiha Food Express is more than just a delivery app; it's a commitment to bringing the finest culinary experiences directly to your doorstep. Founded with a passion for great food and community, we bridge the gap between Naudiha's best kitchens and food lovers.
                    </p>
                    <p>
                        Whether you crave spicy Chinese, comforting snacks, or a hearty main course, our dedicated team ensures your meal arrives hot, fresh, and on time. We believe in quality, hygiene, and the joy of sharing a good meal.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8 relative z-10">
                    <div className="bg-navy-50 rounded-xl p-5 border border-navy-100">
                        <p className="text-xs text-navy-500 font-bold uppercase tracking-wider mb-1">Customer Support</p>
                        <p className="text-lg font-bold text-navy-900">+91 12345 67890</p>
                    </div>
                    <div className="bg-brand-50 rounded-xl p-5 border border-brand-100">
                        <p className="text-xs text-brand-600 font-bold uppercase tracking-wider mb-1">Email Us</p>
                        <p className="text-sm font-bold text-brand-900 break-all">naudihaexpress@gmail.com</p>
                    </div>
                </div>

                <div className="border-t border-gray-100 pt-6 mt-6">
                    <p className="text-xs text-gray-400 font-semibold uppercase tracking-widest flex items-center justify-center gap-1">
                        <Code className="w-3 h-3" />
                        Web Application Developed & Managed by Satish Gupta
                    </p>
                </div>
                
                {/* Background Decor */}
                <div className="absolute top-0 right-0 -mr-16 -mt-16 w-32 h-32 bg-brand-100 rounded-full opacity-50 blur-2xl"></div>
                <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-32 h-32 bg-navy-100 rounded-full opacity-50 blur-2xl"></div>
            </div>
        )}
      </main>

      {/* Cart Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 flex justify-end">
          <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
            <div className="p-5 border-b flex justify-between items-center bg-white">
              <h2 className="font-bold text-xl flex items-center gap-2 text-navy-900">
                <ShoppingBag className="w-6 h-6 text-brand-500" /> Your Cart
              </h2>
              <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-gray-50">
              {cart.length === 0 ? (
                <div className="text-center text-gray-400 mt-20 flex flex-col items-center">
                  <div className="bg-white p-6 rounded-full mb-4 shadow-sm">
                    <ShoppingBag className="w-12 h-12 text-gray-200" />
                  </div>
                  <p className="font-medium text-gray-500">Your cart is empty</p>
                  <button onClick={() => setIsCartOpen(false)} className="mt-4 text-brand-600 font-bold text-sm hover:underline">
                    Browse Menu
                  </button>
                </div>
              ) : (
                cart.map(item => (
                  <div key={item.id} className="flex gap-4 p-4 bg-white rounded-xl shadow-sm border border-gray-100">
                    <img src={item.image} alt="" className="w-20 h-20 rounded-lg object-cover shadow-sm" />
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <h4 className="font-bold text-navy-900 line-clamp-1 text-sm">{item.name}</h4>
                        <p className="text-brand-600 font-bold text-sm">₹{(item.price * item.quantity).toFixed(2)}</p>
                      </div>
                      <div className="flex items-center gap-3 mt-2">
                        <button onClick={() => updateQuantity(item.id, -1)} className="p-1 bg-gray-100 rounded-md hover:bg-gray-200 text-gray-600 transition-colors">
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-sm font-bold w-4 text-center text-navy-900">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, 1)} className="p-1 bg-gray-100 rounded-md hover:bg-gray-200 text-gray-600 transition-colors">
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                    <button onClick={() => removeFromCart(item.id)} className="text-gray-400 hover:text-red-500 self-start p-1 transition-colors">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-6 border-t bg-white shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
                <div className="flex justify-between items-center mb-6">
                  <span className="text-gray-500 font-medium">Subtotal</span>
                  <span className="text-2xl font-bold text-navy-900">₹{cartSubtotal.toFixed(2)}</span>
                </div>
                <button 
                  onClick={() => setIsCheckoutOpen(true)}
                  className="w-full bg-navy-900 hover:bg-navy-800 text-white py-4 rounded-xl font-bold shadow-lg shadow-navy-900/20 transition-all active:scale-[0.98] flex justify-between px-6 items-center group"
                >
                  <span>Proceed to Checkout</span>
                  <div className="flex items-center gap-2">
                     <span className="bg-white/20 px-2 py-0.5 rounded text-sm font-mono">₹{cartSubtotal}</span>
                     <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 bg-navy-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="bg-gray-50 p-6 border-b border-gray-100 flex justify-between items-center">
               <div>
                  <h3 className="text-xl font-bold text-navy-900">Confirm Delivery</h3>
                  <p className="text-xs text-gray-500">Complete your details to place order</p>
               </div>
              <button onClick={() => setIsCheckoutOpen(false)} className="text-gray-400 hover:text-gray-600 p-2 hover:bg-gray-200 rounded-full transition-colors text-gray-500">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePlaceOrder} className="p-6 space-y-5">
              <div className="bg-brand-50/50 p-4 rounded-xl border border-brand-100 flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <div className="bg-white p-2 rounded-lg border border-brand-100">
                        <User className="w-5 h-5 text-brand-600" />
                    </div>
                    <div>
                        <p className="font-bold text-navy-900 text-sm">{user.name}</p>
                        <p className="text-xs text-brand-600 font-medium">{user.mobile}</p>
                    </div>
                </div>
                <span className="text-xs bg-white border border-brand-200 px-2 py-1 rounded text-brand-700 font-bold">CUSTOMER</span>
              </div>

              <div>
                <label className="block text-sm font-bold text-navy-900 mb-2">Delivery Zone</label>
                <div className="grid grid-cols-1 gap-2">
                  {DELIVERY_OPTIONS.map((option) => (
                    <label 
                      key={option.range}
                      className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                        selectedDelivery.range === option.range 
                          ? 'border-brand-500 bg-brand-50 ring-1 ring-brand-500' 
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input 
                          type="radio" 
                          name="delivery"
                          className="text-brand-600 focus:ring-brand-500"
                          checked={selectedDelivery.range === option.range}
                          onChange={() => setSelectedDelivery(option)}
                        />
                        <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
                           <Bike className="w-4 h-4 text-gray-400" />
                           {option.label}
                        </div>
                      </div>
                      <span className="font-bold text-navy-900">₹{option.price}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-navy-900 mb-2">Delivery Address</label>
                <div className="relative">
                    <MapPin className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <textarea
                    required
                    className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all text-sm min-h-[80px]"
                    rows={2}
                    value={address}
                    onChange={e => setAddress(e.target.value)}
                    placeholder="Enter complete address..."
                    />
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-2">
                 <div className="flex justify-between text-sm text-gray-600">
                    <span>Food Total</span>
                    <span>₹{cartSubtotal}</span>
                 </div>
                 <div className="flex justify-between text-sm text-gray-600">
                    <span>Delivery Fee</span>
                    <span>₹{selectedDelivery.price}</span>
                 </div>
                 <div className="flex justify-between text-lg font-bold text-navy-900 pt-2 border-t border-gray-200">
                    <span>Grand Total</span>
                    <span className="text-brand-600">₹{cartSubtotal + selectedDelivery.price}</span>
                 </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-4 rounded-xl shadow-xl shadow-green-600/20 transition-all flex items-center justify-center gap-2 transform active:scale-[0.98]"
                >
                  <Check className="w-5 h-5" /> Place Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-navy-900 text-white px-6 py-3 rounded-full shadow-2xl z-50 flex items-center gap-3 animate-fade-in-up border border-navy-800">
          <div className="bg-green-500 rounded-full p-0.5">
             <Check className="w-3 h-3 text-white" />
          </div>
          <span className="font-medium text-sm">{toast}</span>
        </div>
      )}
    </div>
  );
};