import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, query, orderBy, onSnapshot, doc, updateDoc, where, setDoc, getDoc } from "firebase/firestore";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged, signOut } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyDzRPlnHg-w26Ghakipyw2Me2NqGWzLoGM",
  authDomain: "naudiha-food-delivery.firebaseapp.com",
  projectId: "naudiha-food-delivery",
  storageBucket: "naudiha-food-delivery.firebasestorage.app",
  messagingSenderId: "927389399690",
  appId: "1:927389399690:web:a2107b9b01d06f353e8b73",
  measurementId: "G-VRZD438ENJ"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);
const auth = getAuth(app);
auth.useDeviceLanguage();

export { db, auth, collection, addDoc, query, orderBy, onSnapshot, doc, updateDoc, where, setDoc, getDoc, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged, signOut };