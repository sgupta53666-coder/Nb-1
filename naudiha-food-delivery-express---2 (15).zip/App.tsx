import React, { useState, useEffect } from 'react';
import { Login } from './components/Login';
import { CustomerPanel } from './components/CustomerPanel';
import { AdminPanel } from './components/AdminPanel';
import { UserRole, CustomerProfile } from './types';
import { auth, onAuthStateChanged, db, getDoc, doc } from './services/firebase';

const App: React.FC = () => {
  const [currentRole, setCurrentRole] = useState<UserRole>(UserRole.GUEST);
  const [customerProfile, setCustomerProfile] = useState<CustomerProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Auto-login listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        // User is signed in. Check Firestore for profile.
        try {
          const userDoc = await getDoc(doc(db, "users", user.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            const profile = { name: data.name, mobile: data.mobile };
            setCustomerProfile(profile);
            setCurrentRole(UserRole.CUSTOMER);
            
            // Visual URL update as requested (without reloading)
            window.history.replaceState(null, "Menu", "/menu.html");
          } else {
             // User exists in Auth but not Firestore (rare race condition or new user logic handled in Login)
             // We wait for manual state set from Login component in this case.
          }
        } catch (error) {
          console.error("Error fetching user profile:", error);
        }
      } else {
        // User is signed out
        if (currentRole === UserRole.CUSTOMER) {
           setCurrentRole(UserRole.GUEST);
           setCustomerProfile(null);
           window.history.replaceState(null, "Home", "/");
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currentRole]);

  const handleLogin = (role: UserRole, profile?: CustomerProfile) => {
    if (role === UserRole.CUSTOMER && profile) {
      setCustomerProfile(profile);
      // Visual URL update
      window.history.pushState(null, "Menu", "/menu.html");
    }
    setCurrentRole(role);
  };

  const handleLogout = () => {
    setCurrentRole(UserRole.GUEST);
    setCustomerProfile(null);
    window.history.pushState(null, "Home", "/");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-500"></div>
      </div>
    );
  }

  return (
    <>
      {currentRole === UserRole.GUEST && (
        <Login onLogin={handleLogin} />
      )}
      
      {currentRole === UserRole.CUSTOMER && customerProfile && (
        <CustomerPanel 
          user={customerProfile}
          onLogout={handleLogout} 
        />
      )}
      
      {currentRole === UserRole.ADMIN && (
        <AdminPanel 
          onLogout={handleLogout} 
        />
      )}
    </>
  );
};

export default App;